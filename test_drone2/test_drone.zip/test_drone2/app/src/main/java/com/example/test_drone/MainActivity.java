package com.example.test_drone;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.LineBackgroundSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button boutonConnexion;
    private EditText saisiIdentifiant;
    private EditText saisiMotDePasse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        saisiIdentifiant = findViewById(R.id.identifiant);
        saisiMotDePasse = findViewById(R.id.motDePasse);
        boutonConnexion = findViewById(R.id.connexion);

        boutonConnexion.setEnabled(false);

        saisiIdentifiant.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                boutonConnexion.setEnabled(!s.toString().isEmpty() && !saisiMotDePasse.getText().toString().isEmpty());
            }
        });

        saisiMotDePasse.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                boutonConnexion.setEnabled(!s.toString().isEmpty() && !saisiIdentifiant.getText().toString().isEmpty());
            }
        });


        boutonConnexion.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                if(saisiIdentifiant.getText().toString().equals("maxime") &&
                        saisiMotDePasse.getText().toString().equals("ruppe")){
                    System.out.println("Maxime s'est connecté");
                }
                else if(saisiIdentifiant.getText().toString().equals("nikolai") &&
                        saisiMotDePasse.getText().toString().equals("amosse")){
                    System.out.println("Nikolai s'est connecté");
                }
                else if(saisiIdentifiant.getText().toString().equals("theo") &&
                        saisiMotDePasse.getText().toString().equals("bruyat")){
                    System.out.println("Theo s'est connecté");
                }
                else{
                    System.out.println("Un hackeur s'est connecté");
                }
                Intent controleDroneActivityIntent = new Intent(MainActivity.this, ControleDroneActivity.class);
                startActivity(controleDroneActivityIntent);
            }
        });


    }


}