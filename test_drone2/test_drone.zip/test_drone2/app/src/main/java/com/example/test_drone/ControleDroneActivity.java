package com.example.test_drone;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

public class ControleDroneActivity extends AppCompatActivity {

    private Button onOff;
    private Button camera;
    private Button position;
    private Button takeOffLand;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controle_drone);

        onOff = findViewById(R.id.OnOff);
        camera = findViewById(R.id.camera);
        position = findViewById(R.id.posistion);
        takeOffLand = findViewById(R.id.takeOffLand);

        camera.setEnabled(false);
        position.setEnabled(false);
        takeOffLand.setEnabled(false);

        onOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(onOff.getText().equals(getString(R.string.on))) {
                    onOff.setText(R.string.off);
                    camera.setEnabled(true);
                    position.setEnabled(true);
                    takeOffLand.setEnabled(true);
                }
                else if(onOff.getText().equals(getString(R.string.off))){
                    onOff.setText(R.string.on);
                    camera.setEnabled(false);
                    camera.setText(R.string.cameraOn);
                    position.setEnabled(false);
                    takeOffLand.setEnabled(false);
                }
                else{
                    System.out.println("Erreur lors du clic sur le bouton on/off");
                }
            }
        });

        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(camera.getText().equals(getString(R.string.cameraOn))) {
                    camera.setText(R.string.cameraOff);
                }
                else if(camera.getText().equals(getString(R.string.cameraOff))) {
                    camera.setText(R.string.cameraOn);
                }
                else{
                    System.out.println("Erreur lors du clic sur le boutton camera");
                }
            }
        });

        takeOffLand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(takeOffLand.getText().equals(getString(R.string.takeof))) {
                    takeOffLand.setText(R.string.land);
                    onOff.setEnabled(false);
                }
                else if(takeOffLand.getText().equals(getString(R.string.land))) {
                    takeOffLand.setText(R.string.takeof);
                    onOff.setEnabled(true);
                }
                else{
                    System.out.println("Erreur lors du clic sur le boutton decoller/atterrir");
                }
            }
        });



    }
}